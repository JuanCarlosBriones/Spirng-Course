package mx.unam.fes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
